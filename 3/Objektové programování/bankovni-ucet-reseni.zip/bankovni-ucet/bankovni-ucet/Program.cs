﻿using bankovni_ucet;

class Program
{
    static void Main()
    {
        // Vytvoření nového bankovního účtu
        BankovniUcet mujUcet = new BankovniUcet("Jan Novák", 1000);

        while (true)
        {

            Menu();
            string volba = Console.ReadLine();

            switch (volba)
            {
                case "1":
                    // Zobrazení informací o účtu
                    mujUcet.ZobrazitZustatek();
                    break;
                case "2":
                    // Vložení peněz na účet
                    mujUcet.Vlozit(int.Parse(Console.ReadLine()));
                    break;
                case "3":
                    // Výběr peněz z účtu
                    mujUcet.Vybrat(Convert.ToDouble(Console.ReadLine()));
                    break;
                case "4":
                    // Polsat peníze z účtu
                    mujUcet.Vybrat(Convert.ToDouble(Console.ReadLine()));
                    break;
                case "5":
                    Environment.Exit(0);
                    break;
                default:
                    SpatnaVolba();
                    break;


            }
        }


        void SpatnaVolba()
        {
            Console.WriteLine("Zadal jste špatnou volbu");
        }

        void Menu()
        {
            Console.WriteLine("1. Zobrazit zůstatek");
            Console.WriteLine("2. Vložit peníze");
            Console.WriteLine("3. Vybrat peníze");
            Console.WriteLine("4. Poslat peníze");

            Console.WriteLine("5. Konec");
        }
    }


}

