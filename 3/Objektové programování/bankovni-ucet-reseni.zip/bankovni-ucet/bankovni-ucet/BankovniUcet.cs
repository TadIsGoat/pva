﻿namespace bankovni_ucet
{
    public class BankovniUcet
    {
        // Vlastnosti třídy BankovniUcet
        public string Vlastnik { get; set; }
        public double Zustatek { get; set; }

        // Konstruktor třídy BankovniUcet
        public BankovniUcet(string vlastnik, double pocatecniZustatek)
        {
            Vlastnik = vlastnik;
            Zustatek = pocatecniZustatek;
        }

        // Metoda pro vklad peněz na účet
        public void Vlozit(double castka)
        {
            if (castka > 0)
            {
                Zustatek += castka;
                Console.WriteLine($"Úspěšně vloženo {castka} Kč.");
            }
            else
            {
                Console.WriteLine("Částka vkladu musí být větší než nula.");
            }
        }

        // Metoda pro výběr peněz z účtu
        public void Vybrat(double castka)
        {
            if (castka > 0 && castka <= Zustatek)
            {
                Zustatek -= castka;
                Console.WriteLine($"Úspěšně vybráno {castka} Kč.");
            }
            else
            {
                Console.WriteLine("Neplatná částka výběru nebo nedostatečné finanční prostředky.");
            }
        }

        // Metoda pro zobrazení stavu účtu
        public void ZobrazitZustatek()
        {
            Console.WriteLine($"Vlastník účtu: {Vlastnik}");
            Console.WriteLine($"Aktuální zůstatek: {Zustatek} Kč");
        }

    }
}
